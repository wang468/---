define(function (require, exports, module) {
  module.exports = {
    msg: 'I Will Back'
  }
})