(function (alerter) {
  alerter.showMsg()
})(alerter)