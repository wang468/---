<template>
  <div class="border1">
    <h2>C 结点</h2>
    <ChildrenF />
  </div>
</template>
<script>
import ChildrenF from "./ChildrenF";
export default {
  components: {
    ChildrenF
  }
};
</script>
